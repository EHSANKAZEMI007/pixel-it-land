<?php
include("pageheader.php");
?>
            <!-- ************************* -->
            
            <p class="col">
        <a href="news_add.php">+</a>
    </p>

            <!-- ************************* -->
<?php
include("pagefooter.html");
?>