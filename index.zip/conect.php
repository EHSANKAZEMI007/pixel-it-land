<?php
$link=mysqli_connect("localhost","root","","picxel it");
$link=mysqli_connect("localhost","h314336_sdd","LIiZMc2rpp","h314336_sd");
?>